#!/usr/bin/env bash

hugepages -rx

./xmrig